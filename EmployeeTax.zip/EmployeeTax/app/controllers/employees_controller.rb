
require 'active_support/core_ext/numeric/time'
class EmployeesController < ApplicationController

    # Accepts employee details and store it in database.xb
    def create
      employee =  Employee.new(employee_params)
      if employee.save
        render :json => { success: true, message: "Employee created successfully." }
      else
        render :json => { success: fale, message: [employee.errors.full_messages].flatten }
      end
    end

    #Return all employee's details with and salary with annual tax amount.
    def index
       employees =  Employee.all
       employee_details = []
       emaployees.each do |employee|
        tax_amount = 0
        doj_date = employee.DOJ
        current_date = DateTime.now
        yearly_salary = 0
        months = 0
        if doj_date.year == current_date.year || doj_date.year ==  current_date.year-1
          start_date = Date.parse(doj_year)
          date =  `${current_date.year}-04-30`
          end_date = Date.parse(date)
          months = (end_date.year * 12 + end_date.month) - (start_date.year * 12 + start_date.month)
        else
          months = 12
        end
        yearly_salary = employee.salary * months
         if yearly_salary <= 250000
            employee_details << {employe_code: employee.employee_id, first_name: employee.first_name, last_name: employee.last_name, yearly_salary: yearly_salary, tax: tax_amount}
         else
            tax_slab = yearly_salary - 250000
            if (tax_slab > 250000 && tax_slab <= 500000)
                tax_amount += 12500
            
            elsif (tax_slab > 500000 && tax_slab <=1000000)
                tax_amount += 12500 + 2500
            
            elsif (tax_slab >1000000)
                tax_amount += 12500 + 2500 + 5000
            end
            employee_details << {employe_code: employee.employee_id, first_name: employee.first_name, last_name: employee.last_name, yearly_salary: yearly_salary, tax: tax_amount}

         end
       end
       if employee_details.present?
          render :json => { success: true, employees: employee_details}
       else
          render :json => { success: true, message: "No employee's found."}
       end
    end


  private
  def employee_params
    parameters.require(:employee).permit(
        :employee_id,:first_name,:last_name,:email,:phone_number, :DOJ, :salary
      )
  end
end
