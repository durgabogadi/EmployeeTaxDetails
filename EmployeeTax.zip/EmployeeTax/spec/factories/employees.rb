FactoryBot.define do
  factory :employee do
    first_name {"Durga"}
    last_name {"Bogadu"}
    email {"durgabogadi@gmail.com"}
    phone_number {"9876543212"}
    salary { 600000 }
    DOJ { DateTime.now }
  end
  factory :employee1 do
    first_name {"Raju"}
    last_name {"Bogadu"}
    email {"raju@gmail.com"}
    phone_number {"9876543212"}
    salary { 7500000 }
    DOJ { DateTime.now }
  end
  factory :employee2 do
    first_name {"Durga"}
    last_name {"Bogadu"}
    phone_number {"8765487689"}
    salary { 600000 }
    DOJ { DateTime.now }
    
  end
end
