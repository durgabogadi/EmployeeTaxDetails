require 'rails_helper'

RSpec.describe EmployeesController, type: :controller do
    let(:employee1) {create(:employee1)}
    render_views
    describe "create employee" do
      it "employee created with all parameters" do
          post 'create', params : {employee : {attributes_for(:employee)}}
          expect(json["success"]).to eq(true)
      end
      it "employee created failed due to email param is missed." do
        post 'create', params : {employee : {attributes_for(:employee2)}}
        expect(json["success"]).to eq(false)
        expect(json["message"]).to eq("email is required")
      end
    end
    describe "get employyes tax details" do
      it "get all employee details" do
        employee1
        get 'index'
        expect(json["success"]).to eq(true)
        expect(json["employyes"].count).to be 1
      end
      it "employee created with all parameters" do
        get 'index'
        expect(json["message"]).to eq("No employee's found")
      end
    end

end